package model;

public class BotResponse {
 String speech = "This is server response";
 String displayText = "Server response";
public String getSpeech() {
	return speech;
}
public void setSpeech(String speech) {
	this.speech = speech;
}
public String getDisplayText() {
	return displayText;
}
public void setDisplayText(String displayText) {
	this.displayText = displayText;
}
 
 
}
