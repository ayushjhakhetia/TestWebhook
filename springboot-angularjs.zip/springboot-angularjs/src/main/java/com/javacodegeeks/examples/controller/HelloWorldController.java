package com.javacodegeeks.examples.controller;

import java.io.BufferedReader;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import model.BotRequest;
import model.BotResponse;

@Controller
public class HelloWorldController {

    @RequestMapping(value = "/fullfillment",method = RequestMethod.POST)
    public @ResponseBody WebhookResponse webhook(@RequestBody String dr){

       

  	  BotResponse botResponse = new BotResponse();
  	  BotRequest botRequest = null;
  	  ObjectMapper mapper = new ObjectMapper();
  	  try {
  		botRequest = mapper.readValue(dr, BotRequest.class);
	} catch (JsonParseException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (JsonMappingException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
  	  
  	 
  	  if(botRequest != null){
  		  int num1 = botRequest.getResult().getParameters().getCapacity();
  		  int num2 = botRequest.getResult().getParameters().getDuration().getAmount();
  		  
  		  botResponse.setSpeech("Capacity Server Response: "+num1+" Duration: "+num2);
  		  botResponse.setDisplayText("Capacity Server Response: "+num1+" Duration: "+num2);
  	  }
  	  
  	

        return new WebhookResponse(botResponse.getSpeech(), botResponse.getDisplayText());
    }
}
