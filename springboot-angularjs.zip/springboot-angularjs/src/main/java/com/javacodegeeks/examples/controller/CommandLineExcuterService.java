package com.javacodegeeks.examples.controller;

public interface CommandLineExcuterService  {
	
	public String executeCommand(String cmd);

}
