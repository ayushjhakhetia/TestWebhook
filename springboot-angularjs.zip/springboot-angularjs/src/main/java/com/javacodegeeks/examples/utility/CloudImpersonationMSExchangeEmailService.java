package com.javacodegeeks.examples.utility;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import microsoft.exchange.webservices.data.autodiscover.IAutodiscoverRedirectionUrl;
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.enumeration.misc.ConnectingIdType;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.enumeration.search.ResolveNameSearchLocation;
import microsoft.exchange.webservices.data.core.exception.http.EWSHttpException;
import microsoft.exchange.webservices.data.core.exception.service.local.ServiceLocalException;
import microsoft.exchange.webservices.data.core.exception.service.remote.ServiceResponseException;
import microsoft.exchange.webservices.data.core.service.folder.CalendarFolder;
import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.core.service.item.Appointment;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.core.service.schema.AppointmentSchema;
import microsoft.exchange.webservices.data.core.service.schema.ItemSchema;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.misc.ImpersonatedUserId;
import microsoft.exchange.webservices.data.misc.NameResolution;
import microsoft.exchange.webservices.data.misc.NameResolutionCollection;
import microsoft.exchange.webservices.data.property.complex.Attendee;
import microsoft.exchange.webservices.data.property.complex.EmailAddress;
import microsoft.exchange.webservices.data.property.complex.EmailAddressCollection;
import microsoft.exchange.webservices.data.property.complex.FolderId;
import microsoft.exchange.webservices.data.property.complex.ItemId;
import microsoft.exchange.webservices.data.property.complex.Mailbox;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import microsoft.exchange.webservices.data.search.CalendarView;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.ItemView;
import microsoft.exchange.webservices.data.search.filter.SearchFilter;
/*
import microsoft.exchange.webservices.data.Appointment;
import microsoft.exchange.webservices.data.AppointmentSchema;
import microsoft.exchange.webservices.data.Attendee;
import microsoft.exchange.webservices.data.CalendarFolder;
import microsoft.exchange.webservices.data.CalendarView;
import microsoft.exchange.webservices.data.ConnectingIdType;
import microsoft.exchange.webservices.data.EWSHttpException;
import microsoft.exchange.webservices.data.EmailAddress;
import microsoft.exchange.webservices.data.EmailAddressCollection;
import microsoft.exchange.webservices.data.EmailMessage;
import microsoft.exchange.webservices.data.ExchangeService;
import microsoft.exchange.webservices.data.ExchangeVersion;
import microsoft.exchange.webservices.data.FindItemsResults;
import microsoft.exchange.webservices.data.Folder;
import microsoft.exchange.webservices.data.FolderId;
import microsoft.exchange.webservices.data.IAutodiscoverRedirectionUrl;
import microsoft.exchange.webservices.data.ImpersonatedUserId;
import microsoft.exchange.webservices.data.Item;
import microsoft.exchange.webservices.data.ItemId;
import microsoft.exchange.webservices.data.ItemSchema;
import microsoft.exchange.webservices.data.ItemView;
import microsoft.exchange.webservices.data.Mailbox;
import microsoft.exchange.webservices.data.MessageBody;
import microsoft.exchange.webservices.data.NameResolution;
import microsoft.exchange.webservices.data.NameResolutionCollection;
import microsoft.exchange.webservices.data.PropertySet;
import microsoft.exchange.webservices.data.ResolveNameSearchLocation;
import microsoft.exchange.webservices.data.SearchFilter;
import microsoft.exchange.webservices.data.ServiceLocalException;
import microsoft.exchange.webservices.data.ServiceResponseException;
import microsoft.exchange.webservices.data.WebCredentials;
import microsoft.exchange.webservices.data.WellKnownFolderName;
*/
public class CloudImpersonationMSExchangeEmailService {

    public static class RedirectionUrlCallback implements IAutodiscoverRedirectionUrl {
        public boolean autodiscoverRedirectionUrlValidationCallback(String redirectionUrl) {
          return redirectionUrl.toLowerCase().startsWith("https://");
        }
    }

    private static ExchangeService service;
    private static Integer NUMBER_EMAILS_FETCH =5; // only latest 5 emails/appointments are fetched.
    /**
     * Firstly check, whether "https://webmail.xxxx.com/ews/Services.wsdl" and "https://webmail.xxxx.com/ews/Exchange.asmx"
     * is accessible, if yes that means the Exchange Webservice is enabled on your MS Exchange.
     */
    static{
		try {
			service = new ExchangeService();
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    /**
     * Initialize the Exchange Credentials. 
     * Don't forget to replace the "USRNAME","PWD","DOMAIN_NAME" variables. 
     */
    public CloudImpersonationMSExchangeEmailService(String impersonateServiceUserId,String impersonateServicePwd,String impersonatedUserId) {
    	service.setCredentials(new WebCredentials(impersonateServiceUserId,impersonateServicePwd));
    	ImpersonatedUserId id = new ImpersonatedUserId(ConnectingIdType.SmtpAddress,impersonatedUserId);
    	service.setImpersonatedUserId(id);
    	
    	try {
    		//service.autodiscoverUrl(impersonateServiceUserId, new RedirectionUrlCallback());
    		//service.autodiscoverUrl("https://outlook.office365.com/ews/exchange.asmx");
    		//service.autodiscoverUrl("https://outlook.office365.com/EWS/Exchange.asmx");
    		                         
    		//service.autodiscoverUrl(impersonatedUserId, new RedirectionUrlCallback());
    		// service.autodiscoverUrl("https://outlook.office365.com/EWS/Exchange.asmx", new RedirectionUrlCallback());
    		//service.autodiscoverUrl("ashish.jain@impetus.co.in");
    		//service.autodiscoverUrl("https://outlook.office365.com/EWS/Exchange.asmx");
    		
    		service.setUrl(new URI ("https://outlook.office365.com/EWS/Exchange.asmx"));
        } catch (Exception ex) {
            Logger.getLogger(CloudImpersonationMSExchangeEmailService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Reading one email at a time. Using Item ID of the email.
     * Creating a message data map as a return value.   
     */
    public Map readEmailItem(ItemId itemId){
        Map messageData = new HashMap();
        try{
            Item itm = Item.bind(service, itemId, PropertySet.FirstClassProperties);
            EmailMessage emailMessage = EmailMessage.bind(service, itm.getId());
            messageData.put("emailItemId", emailMessage.getId().toString());
            messageData.put("subject", emailMessage.getSubject().toString());
            messageData.put("fromAddress",emailMessage.getFrom().getAddress().toString());
            messageData.put("senderName",emailMessage.getSender().getName().toString());
            Date dateTimeCreated = emailMessage.getDateTimeCreated();
            messageData.put("SendDate",dateTimeCreated.toString());
            Date dateTimeRecieved = emailMessage.getDateTimeReceived();
            messageData.put("RecievedDate",dateTimeRecieved.toString());
            messageData.put("Size",emailMessage.getSize()+"");
            messageData.put("emailBody",emailMessage.getBody().toString());
        }catch (Exception e) {
            e.printStackTrace();
        }
        return messageData;
    }
    /**
     * Number of email we want to read is defined as NUMBER_EMAILS_FETCH, 
     */
	public List readEmails() {
		long startTime = System.currentTimeMillis();
		List msgDataList = new ArrayList();
		try {
			Folder folder = Folder.bind(service, WellKnownFolderName.Inbox);
			FindItemsResults<Item> results = service.findItems(folder.getId(), new ItemView(NUMBER_EMAILS_FETCH));
			int i = 1;
			for (Item item : results) {
				Map messageData = new HashMap();
				messageData = readEmailItem(item.getId());
				System.out.println("\nEmails #" + (i++) + ":");
				System.out.println("subject : " + messageData.get("subject").toString());
				System.out.println("Sender : " + messageData.get("senderName").toString());
				msgDataList.add(messageData);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			long endTime = System.currentTimeMillis();
			long duration = (endTime - startTime);
			System.out.println("readEmails process execution time: " + duration + "MS");
		}
		return msgDataList;
	}
    /**
     * Reading one appointment at a time. Using Appointment ID of the email.
     * Creating a message data map as a return value.   
     */
    public Map readAppointment(Appointment appointment){
        Map appointmentData = new HashMap();
        try {
            appointmentData.put("appointmentItemId", appointment.getId().toString());
            appointmentData.put("appointmentSubject", appointment.getSubject());
            appointmentData.put("appointmentStartTime", appointment.getStart()+"");
            appointmentData.put("appointmentEndTime", appointment.getEnd()+"");
            //appointmentData.put("appointmentBody", appointment.getBody().toString());
        } catch (ServiceLocalException e) {
            e.printStackTrace();
        }
        return appointmentData;
    }
    /**
      *Number of Appointments we want to read is defined as NUMBER_EMAILS_FETCH,
      *  Here I also considered the start data and end date which is a 30 day span.
      *  We need to set the CalendarView property depending upon the need of ours.   
     */
    public List readAppointments(){
        List apntmtDataList = new ArrayList();
        Calendar now = Calendar.getInstance();
        Date startDate = Calendar.getInstance().getTime();
        now.add(Calendar.DATE, 30);
                Date endDate = now.getTime();  
        try{
            CalendarFolder calendarFolder = CalendarFolder.bind(service, WellKnownFolderName.Calendar, new PropertySet());
            CalendarView cView = new CalendarView(startDate, endDate, 5);
            cView.setPropertySet(new PropertySet(AppointmentSchema.Subject, AppointmentSchema.Start, AppointmentSchema.End));// we can set other properties as well depending upon our need.

            //FindItemsResults appointments = calendarFolder.findAppointments(cView);
            FindItemsResults<Appointment> appointments = calendarFolder.findAppointments(cView);
            System.out.println("|------------------> Appointment count = " + appointments.getTotalCount());
            int i =1;
            //List appList = appointments.getItems();
            for (Appointment appointment : appointments.getItems()) {
                System.out.println("\nAPPOINTMENT #" + (i++ ) + ":" );
                Map appointmentData = new HashMap();
                appointmentData = readAppointment(appointment);
                System.out.println("subject : " + appointmentData.get("appointmentSubject").toString());
                System.out.println("On : " + appointmentData.get("appointmentStartTime").toString());
                apntmtDataList.add(appointmentData);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
       return apntmtDataList;
    }
    
    public static void findAllRoomByLocation() throws Exception{
    	NameResolutionCollection nameResolutions = service.resolveName("Crystal IT Park Second Floor Conference Room",ResolveNameSearchLocation.DirectoryOnly, true);
		System.out.println("nameResolutions===" + nameResolutions.getCount());
		for (Object nameResolution1 : nameResolutions) {
			NameResolution nameResolution = (NameResolution) nameResolution1;
			System.out.println("NAME===" + nameResolution.getContact().getDisplayName());
		}
    }
    
    public static void createAppotiment() throws Exception {
    	Appointment appoitment;
		try {
			appoitment = new Appointment(service);
			appoitment.setSubject("New test2");
			appoitment.setBody(new MessageBody("test message"));
			appoitment.setStart(new Date());
			long afterHouTS = System.currentTimeMillis() + TimeUnit.HOURS.toMillis(1);
			appoitment.setEnd(new Date(afterHouTS));
			Attendee a = new Attendee(new EmailAddress("ashish.jain@impetus.co.in"));
			appoitment.getRequiredAttendees().add(a);
			appoitment.save();
		} catch (Exception e) {
			throw new Exception("No mailbox is configure on exchange for this email",e);
		}
    }

    public static void getAllMeetings(){
     try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date startDate = formatter.parse("2017-11-03 00:00:00");
			SearchFilter filter = new SearchFilter.IsGreaterThanOrEqualTo(ItemSchema.LastModifiedTime, startDate);
			FindItemsResults<Item> findResults = service.findItems(WellKnownFolderName.Calendar, filter,
					new ItemView(1000));
			System.out.println("|------------------> meetings count = " + findResults.getTotalCount());
			for (Item item : findResults.getItems()) {
				Appointment appt = (Appointment) item;
				// appt.setStartTimeZone();
				System.out.println("TimeZone=====" + appt.getTimeZone());
				System.out.println("SUBJECT=====" + appt.getSubject());
				System.out.println("Location========" + appt.getLocation());
				System.out.println("Start Time========" + appt.getStart());
				System.out.println("End Time========" + appt.getEnd());
				System.out.println("Email Address========" + appt.getOrganizer().getAddress());
				System.out.println("Last Modified Time========" + appt.getLastModifiedTime());
				System.out.println("Last Modified Time========" + appt.getLastModifiedName());
				System.out.println("*************************************************\n");
				// findAppointments(appt);
			}
		} catch (Exception exp) {
			exp.printStackTrace();
		}
    }

	public static void findAppointments(Date startDate, Date endDate, String emailToSearchAppointment) {
		Mailbox meetingMailbox = new Mailbox(emailToSearchAppointment);
		FolderId CalendarId = new FolderId(WellKnownFolderName.Calendar, meetingMailbox);
		CalendarView cView = new CalendarView(startDate, endDate);
		FindItemsResults<Appointment> appointments = null;
		
		
		try {
			appointments = service.findAppointments(CalendarId, cView);
			for (Item item : appointments.getItems()) {
				Appointment a = (Appointment) item;
				System.out.println("Subject: " + a.getSubject().toString() + " ");
				System.out.println("Start: " + a.getStart().toString() + " ");
				System.out.println("End: " + a.getEnd().toString());
			}
		} catch (ServiceLocalException srvLocEx) {
			System.out.println(srvLocEx.getMessage());
			srvLocEx.printStackTrace();

		} catch (ServiceResponseException srvResEx) {
			System.out.println(srvResEx.getMessage());
			srvResEx.printStackTrace();
		} catch (EWSHttpException ewsHttpEx) {
			System.out.print(ewsHttpEx.getMessage());
			ewsHttpEx.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}    
    
	public static void getMeetingRooms() {
		EmailAddressCollection eac;
		try {
			eac = service.getRoomLists();
			Iterator<EmailAddress> itr = eac.iterator();
			while (itr.hasNext()) {
				EmailAddress email = itr.next();
				System.out.println("Meeting Room name: " + email.getName());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}    
        
    public static void main(String[] args) {
    	
    	long startTime = System.currentTimeMillis();
    	//On premises settings
    	//String impersonateServiceUserId = "UA-Impersonate-SA@impetus.co.in";
      //	String impersonateServicePassword = "DYHq-7&M";
      	
      	String impersonateServiceUserId = "UA-Impersonate-SACloud@impetus.co.in";
      	String impersonateServicePassword = "#8DttDP6";
      	
    	//String impersonateEmail = "arpit.bhatt@impetus.co.in";
    	
    	//impersonation account for cloud
    	//String impersonateServiceUserId = "UA-Impersonate-SACloud@impetus.co.in";
    	//String impersonateServicePassword = "#8DttDP6";
    	String impersonateEmail = "raja.pateriya@impetus.co.in";
    	//String impersonateServicePassword = "impetus#12345";
      	//String impersonateEmail = "UA-Impersonate-SA@impetus.co.in";
    	
        CloudImpersonationMSExchangeEmailService imsees = new CloudImpersonationMSExchangeEmailService(impersonateServiceUserId, impersonateServicePassword,impersonateEmail);
         //imsees.readEmails();
        //msees.readAppointments();
        try {
          
        	//imsees.readEmails();
        	//imsees.getAllMeetings();
        	imsees.findAllRoomByLocation();
        	//imsees.createAppotiment();
        	//imsees.getMeetingRooms();
        	//use case to search appointments based on criteria star, end and email id
        	Date startDate = new Date();
    		Calendar cal = Calendar.getInstance();
    		cal.setTime(startDate);
    		cal.add(Calendar.DATE, 30); // add 10 days
         	Date endDate = cal.getTime();
    	    //imsees.findAppointments(startDate,endDate,"gaurav.vohra@impetus.co.in");
         	//imsees.findAppointments(startDate,endDate,"arpit.bhatt@impetus.co.in");
        	//imsees.getMeetingRoos();
        } catch (Exception ex) {
        	System.out.println(ex.getMessage());
        	//ex.printStackTrace();
            Logger.getLogger(CloudImpersonationMSExchangeEmailService.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
        	long endTime = System.currentTimeMillis();
        	long duration = (endTime - startTime); 
             System.out.println("Total process execution time: "+duration+ "MS");    		
        
		}
    }
}



