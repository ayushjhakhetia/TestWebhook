package com.javacodegeeks.examples.controller;

import java.io.BufferedReader;
import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.javacodegeeks.examples.utility.AppUtility;

import model.BotRequest;
import model.BotResponse;


@RestController
public class MainController {


    @RequestMapping(value="/",method = RequestMethod.GET)
    public String homepage(){
        return "index";
    }
    
    String path = "Users/xactly/jenkins/workspace/QA_Build/Xactly/device.txt";
    
    @RequestMapping(value = "/submitDeviceInfo", method=RequestMethod.GET)
    public String submitDeviceInfor( HttpServletRequest request,HttpServletResponse response, ModelMap map) {
         
    	

//   		String email = request.getParameter("email");
//   		String udid = request.getParameter("udid");
//   		 
//   		CommandLineExcuterService commandLineExcuterService = new CommandLineExecuterServiceImpl();
//   		String command1 = commandLineExcuterService.executeCommand("cd /Users/xactly/jenkins/workspace/QA_Build/Xactly");
//   		String command2 = commandLineExcuterService.executeCommand("fastlane generateBuild");
//   		
    	File f = new File(path);
    	
    	if(f.exists()){
    		f.delete();
    	}
   	
		return "";
   		 
    }
    
    @RequestMapping(value = "/addDeviceUdid", method=RequestMethod.GET)
    public String addDeviceUdid( HttpServletRequest request,HttpServletResponse response, ModelMap map) {
         
    	File f = new File(path);
    	if(!f.exists()){
    		AppUtility.createFile(path);
    	}
    	String email = request.getParameter("email");
       	String udid = request.getParameter("udid");
       	String deviceName = request.getParameter("deviceName");
       	String data = ""+udid+"	"+deviceName;
       	AppUtility.appendFile(path, data);
    	
		return "";
   		 
    }    
   
}
