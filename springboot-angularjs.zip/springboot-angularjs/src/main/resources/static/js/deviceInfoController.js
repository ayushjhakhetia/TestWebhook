mainApp.controller('deviceInfoController', function($scope,$http) {
  $scope.reset = function() {
    $scope.udid = "Enter UDID";
    $scope.email = "Enter Email";
  }

  $scope.submit = function() {
    var emailaddress = document.getElementById("emailAddress").value;
		var ud_id= document.getElementById("udidAddress").value;
    var dataToPost = {
      "url" :window.location.origin
          + "/submitDeviceInfo?email="+emailaddress+"&udid="+ud_id,
      "method" : "GET",
      "headers" : {
        "cache-control" : "no-cache"
      }
    };

    $http(dataToPost)
        .then(
            function successCallback(response) {
             alert("success");

            }, function errorCallback(response) {
              alert("fail");
            });
  }

  $scope.reset();

});
